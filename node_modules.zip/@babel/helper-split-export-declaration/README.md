# @babel/helper-split-export-declaration

> 

See our website [@babel/helper-split-export-declaration](https://babeljs.io/docs/en/babel-helper-split-export-declaration) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-split-export-declaration
```

or using yarn:

```sh
yarn add @babel/helper-split-export-declaration
```
